"""Validation and SQLite persistence for customer orders."""

import json
import sqlite3
from collections.abc import Mapping


class OrderValidationError(ValueError):
    """Raised when an order does not meet the supported input contract."""


def validate_order(order: Mapping[str, object]) -> None:
    """Validate an order mapping before it is persisted."""
    if not isinstance(order, Mapping):
        raise OrderValidationError("Order must be a mapping.")

    order_id = order.get("order_id")
    if not isinstance(order_id, str) or not order_id.strip():
        raise OrderValidationError("order_id must be a non-empty string.")

    email = order.get("customer_email")
    if not isinstance(email, str):
        raise OrderValidationError("customer_email must be a string.")
    local, separator, domain = email.strip().partition("@")
    if not separator or not local or "." not in domain or domain.startswith("."):
        raise OrderValidationError("customer_email must be a valid email address.")

    items = order.get("items")
    if not isinstance(items, list) or not items:
        raise OrderValidationError("items must be a non-empty list.")
    for index, item in enumerate(items):
        if not isinstance(item, Mapping):
            raise OrderValidationError(f"items[{index}] must be a mapping.")
        sku = item.get("sku")
        if not isinstance(sku, str) or not sku.strip():
            raise OrderValidationError(f"items[{index}].sku must be a non-empty string.")
        quantity = item.get("quantity")
        if isinstance(quantity, bool) or not isinstance(quantity, int) or quantity <= 0:
            raise OrderValidationError(f"items[{index}].quantity must be a positive integer.")


def save_order(connection: sqlite3.Connection, order: Mapping[str, object]) -> None:
    """Validate and save an order as JSON in the SQLite database."""
    validate_order(order)
    payload = json.dumps(dict(order), separators=(",", ":"), sort_keys=True)
    with connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS orders (
                order_id TEXT PRIMARY KEY,
                payload TEXT NOT NULL
            )
            """
        )
        connection.execute(
            "INSERT INTO orders (order_id, payload) VALUES (?, ?)",
            (order["order_id"], payload),
        )
