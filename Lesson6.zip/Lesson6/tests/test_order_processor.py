import json
import sqlite3

import pytest

from order_processor import OrderValidationError, save_order, validate_order


@pytest.fixture
def valid_order() -> dict[str, object]:
    return {
        "order_id": "order-123",
        "customer_email": "buyer@example.com",
        "items": [{"sku": "widget-1", "quantity": 2}],
    }


@pytest.mark.parametrize(
    ("field", "value"),
    [
        ("order_id", ""),
        ("order_id", "   "),
        ("order_id", 123),
        ("customer_email", "buyerexample.com"),
        ("customer_email", "@example.com"),
        ("customer_email", "buyer@"),
        ("customer_email", "buyer@.com"),
        ("items", []),
        ("items", "not-a-list"),
    ],
)
def test_validate_order_rejects_invalid_fields(
    valid_order: dict[str, object], field: str, value: object
) -> None:
    valid_order[field] = value

    with pytest.raises(OrderValidationError):
        validate_order(valid_order)


@pytest.mark.parametrize(
    "item",
    [
        "not-a-mapping",
        {},
        {"sku": "   ", "quantity": 1},
        {"sku": "widget-1", "quantity": 0},
        {"sku": "widget-1", "quantity": -1},
        {"sku": "widget-1", "quantity": True},
        {"sku": "widget-1", "quantity": "2"},
    ],
)
def test_validate_order_rejects_invalid_items(
    valid_order: dict[str, object], item: object
) -> None:
    valid_order["items"] = [item]

    with pytest.raises(OrderValidationError):
        validate_order(valid_order)


def test_validate_order_accepts_valid_order(valid_order: dict[str, object]) -> None:
    validate_order(valid_order)


def test_save_order_persists_valid_order(valid_order: dict[str, object]) -> None:
    with sqlite3.connect(":memory:") as connection:
        save_order(connection, valid_order)
        row = connection.execute(
            "SELECT order_id, payload FROM orders"
        ).fetchone()

    assert row is not None
    assert row[0] == "order-123"
    assert json.loads(row[1]) == valid_order


def test_save_order_does_not_insert_invalid_order(valid_order: dict[str, object]) -> None:
    valid_order["items"] = []

    with sqlite3.connect(":memory:") as connection:
        with pytest.raises(OrderValidationError):
            save_order(connection, valid_order)
        table = connection.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'orders'"
        ).fetchone()

    assert table is None


def test_save_order_surfaces_duplicate_order_id(valid_order: dict[str, object]) -> None:
    with sqlite3.connect(":memory:") as connection:
        save_order(connection, valid_order)

        with pytest.raises(sqlite3.IntegrityError):
            save_order(connection, valid_order)
